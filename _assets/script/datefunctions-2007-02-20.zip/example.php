<?php

require_once("datefunctions.class.php");

$date1 = mktime(0, 0, 0, 6, 4, 2006);
$date2 = mktime(10, 0, 0, 1, 2, 2007);
$date3 = mktime(10, 2, 0, 1, 2, 2007);
$date4 = mktime(0, 0, 0, date("m"), date("d"), date("Y"));
$date5 = time() - 15;

echo "Theses to dates (". date("Y-m-d H:i:s", $date1) .", ". date("Y-m-d H:i:s", $date2) .") are this far apart: ". DateFunction::relevantPeriod($date1, $date2) ."<br />";
echo "Theses to dates (". date("Y-m-d H:i:s", $date2) .", ". date("Y-m-d H:i:s", $date3) .") are this far apart: ". DateFunction::relevantPeriod($date2, $date3) ."<br />";

echo date("Y-m-d H:i:s", $date3) ." is best described as ". DateFunction::relevantTime($date3) ."<br />";
echo date("Y-m-d H:i:s", $date4) ." is best described as ". DateFunction::relevantTime($date4) ."<br />";
echo date("Y-m-d H:i:s", $date5) ." is best described as ". DateFunction::relevantTime($date5) ."<br />";

?>