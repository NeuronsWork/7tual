<?php

class DateFunction {
	/**
	 * Convert SQL timestamp to Unix timestamp
	 *
	 * @param	string
	 * @return	timestamp
	 * @access	public
	 */
	public function php_time($date) {
		// 2006-05-10 00:00:00
		// 0123456789012345678
		return mktime(	(int)substr($date, 11, 2),	// Hours
						(int)substr($date, 14, 2),	// Minutes
						(int)substr($date, 17, 2),	// Seconds
						(int)substr($date, 5, 2),	// Months
						(int)substr($date, 8, 2),	// Days
						(int)substr($date, 0, 4));	// Years
	}

	/**
	 * Returns the time between two dates in the
	 * most relevant unit [sec - months].
	 *
	 * @param	start	(unix format)
	 * @param	end		(unix format)
	 * @return	string
	 * @access	public
	 */
	public function relevantPeriod($start, $end) {
		$time = $end - $start;
		if ($time < 0) {
			return DateFunction::relevantPeriod($end, $start) ." ago";
		} else if ($time < 60) {
			return $time ." sec";
		} else if ($time < 3600) {
			return ceil($time / 60) ." min";
		} else if ($time < 86400) {
			return ceil($time / 3600) ." hours";
		}  else if ($time < 604800) {
			return ceil($time / 86400) ." days";
		} else {
			return ceil($time / 2592000) ." months";
		}
	}
	
	/**
	 * Returns a formated date set to a relevant
	 * interval [x seconds ago - Y-m-d]
	 *
	 * @param	time	(unix format)
	 * @return	string
	 * @access	public
	 */
	public function relevantTime($time) {
		if (date("Y-m-d") == date("Y-m-d", $time)) {
			if (date("H") == date("H", $time)) {
				if (date("i") == date("i", $time)) {
					return date("s") - date("s", $time) ." sec ago";
				} else {
					return date("i") - date("i", $time) ." min ago";
				}
			} else {
				return date("g:ia", $time);
			}
		} else if (date("Y") == date("Y", $time)) {
			return date("j M ga", $time);
		} else {
			return date("j M Y", $time);
		}
	}
}