Select-or-Die
=============

Yet another jQuery plugin to style select elements. I'm to lazy to update this readme file with the documentation. Head over to http://vst.mn/selectordie/ to view the Select or Die in action and read all about it.

You can also install it using Bower:
`bower install SelectOrDie`