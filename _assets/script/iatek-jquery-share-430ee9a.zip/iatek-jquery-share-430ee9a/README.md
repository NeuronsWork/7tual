jquery-share - A jQuery social plugin for simultaneous sharing to multiple social networks
================

Tired of social sharing plugins that make you share to each social network seperately? Then you'll love this easy-to-use jQuery social media plugin.
jQuery Share is a plugin that lets you (and your blog readers and Website users) share your content to multiple social networks from one place.
Use Share to post updates, content or screenshots to Facebook, Twitter, Pinterest, Digg, Google+, LinkedIn, Tumblr or email.

Features
================

    - Share updates from multiple social networks from a single form
    - Supports Facebook, Twitter, LinkedIn, Tumblr and In1.
    - Attractive buttons and multiple themes
    - Easy to implement with just a few lines of code
    
Examples
================

[Click here for more information and examples][1]
[1]: http://plugins.in1.com/share