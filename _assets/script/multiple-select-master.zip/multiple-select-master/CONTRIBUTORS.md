## Contributors

multiple-select is due to the excellent work of the following contributors:

<table>
<tr>
<th>Author</th>
<th>Github</th>
<th>Location</th>
<th>Blog</th>
<th>Commits</th>
</tr>

<tr>
<td><img src="https://avatars.githubusercontent.com/u/2117018?" width="32" height="32"> <a href="mailto:wenzhixin2010@gmail.com">文翼</a></td>
<td><a href="https://github.com/wenzhixin">wenzhixin</a></td>
<td>Guangzhou, China</td>
<td><a href="http://wenzhixin.net.cn">http://wenzhixin.net.cn</a></td>
<td>127</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/20234?" width="32" height="32"> Brett Zamir</td>
<td><a href="https://github.com/brettz9">brettz9</a></td>
<td>Shenzhen, China</td>
<td><a href="http://brett-zamir.me">http://brett-zamir.me</a></td>
<td>11</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/3852906?" width="32" height="32"> nicolas-joubert</td>
<td><a href="https://github.com/nicolas-joubert">nicolas-joubert</a></td>
<td>Lyon, France</td>
<td></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/4736139?" width="32" height="32"> <a href="mailto:e.marguin@agence-codecouleurs.fr">Eric Marguin</a></td>
<td><a href="https://github.com/emarguin">emarguin</a></td>
<td>France</td>
<td><a href="http://www.agence-codecouleurs.fr">http://www.agence-codecouleurs.fr</a></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1726913?" width="32" height="32"> Sergio</td>
<td><a href="https://github.com/sergiomcalzada">sergiomcalzada</a></td>
<td></td>
<td></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/5041046?" width="32" height="32"> <a href="mailto:just@tut.by">Andrei</a></td>
<td><a href="https://github.com/JustAndrei">JustAndrei</a></td>
<td>Belarus, Minsk</td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/14005?" width="32" height="32"> <a href="mailto:fedesoria@gmail.com">Federico Soria</a></td>
<td><a href="https://github.com/fedesoria">fedesoria</a></td>
<td>San Francisco</td>
<td><a href="paybygroup.com">paybygroup.com</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/2584275?" width="32" height="32"> guli</td>
<td><a href="https://github.com/guli">guli</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1297559?" width="32" height="32"> Jona Goldman</td>
<td><a href="https://github.com/jonagoldman">jonagoldman</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/7594976?" width="32" height="32"> topas08</td>
<td><a href="https://github.com/topas08">topas08</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/62062?" width="32" height="32"> <a href="mailto:gaurav@jassal.me">Gaurav Jassal</a></td>
<td><a href="https://github.com/creativeaura">creativeaura</a></td>
<td>London</td>
<td><a href="http://gaurav.jassal.me">http://gaurav.jassal.me</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/2769778?" width="32" height="32"> jwheadon</td>
<td><a href="https://github.com/jwheadon">jwheadon</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/479088?" width="32" height="32"> <a href="mailto:tmacey@boundlessnotions.com">Tobias Macey</a></td>
<td><a href="https://github.com/blarghmatey">blarghmatey</a></td>
<td>Boston, MA</td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1058901?" width="32" height="32"> <a href="mailto:xavier@dutreilh.com">Xavier Dutreilh</a></td>
<td><a href="https://github.com/xavierdutreilh">xavierdutreilh</a></td>
<td>Paris, France</td>
<td><a href="http://xavier.dutreilh.com/">http://xavier.dutreilh.com/</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1628706?" width="32" height="32"> Alex Jeffrey</td>
<td><a href="https://github.com/ajeffrey">ajeffrey</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>

</table>

Update date: 2014-07-13, created with https://github.com/wenzhixin/github-contributors