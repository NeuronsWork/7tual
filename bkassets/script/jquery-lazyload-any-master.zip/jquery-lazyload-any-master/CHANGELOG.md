# v0.2.3 / 2014-10-21

* Add refresh method for element move.
* Fixed JSHint warnings.

# v0.2.2 / 2014-10-21

* Enhance performance.
* Enable event if document is not ready.

# v0.2.1 / 2014-10-21

* Enhance performance.
* Fixed trim bug in older browsers.

# v0.2.0 / 2014-10-12

* Support overflow div.
* Support display none and show.

# v0.1.9 / 2014-09-23

* Bind resize and scroll events only on demand.

# v0.1.8 / 2014-07-27

* Support for jquery 1.6.4

# v0.1.7 / 2014-07-01

* Support for jquery 1.9.1

# v0.1.6 / 2014-04-29

* Add detection when initializing.

# v0.1.5 / 2014-04-24

* Support older version jQuery(test 1.6.4).

# v0.1.4 / 2014-02-04

* Rewrite to avoid event listener lost.

# v0.1.3 / 2014-02-03

* Add trigger option.

# v0.1.2 / 2014-01-28

* Add load callback.

# v0.1.1 / 2014-01-22

* Add x-axis detection.
* Add threshold.

# v0.1.0 / 2014-01-19

Initial release
